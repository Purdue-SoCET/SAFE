#include <stdio.h>

int a(){
	int b = 3;
	printf("%d", b);
}


int main(){
	a();
}
