#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#define PATH_TO_COMPILER "/"

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("Wrong number of arguments:\nUsage: mips-cc <filename>\n");
        int i;
        for (i = 0; i < argc; i++) {
            printf("%s", argv[i]);
        }
        exit(EXIT_FAILURE);
    }
    execl("/usr/bin/env", "/usr/bin/env", "python", PATH_TO_COMPILER, argv[1], (char *) 0);

    exit(EXIT_SUCCESS);
}
