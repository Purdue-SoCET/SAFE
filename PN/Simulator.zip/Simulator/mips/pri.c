#include <stdarg.h>
void a(int b, ...){
	int c = 3;
	va_list ap;
	va_start(ap, b);
	va_arg(ap, int);
		c += 1;	
	va_end(ap);
	return;
}

int main(){
	a(3, 4);
	return 0;
}
