/* A Bison parser, made by GNU Bison 3.0.4.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    kADD = 258,
    kADDI = 259,
    kADDIU = 260,
    kADDU = 261,
    kAND = 262,
    kANDI = 263,
    kBEQ = 264,
    kBNE = 265,
    kBLEZ = 266,
    kBGTZ = 267,
    kBGEZ = 268,
    kBLTZ = 269,
    kJ = 270,
    kJAL = 271,
    kJR = 272,
    kLBU = 273,
    kLHU = 274,
    kLUI = 275,
    kLW = 276,
    kNOR = 277,
    kOR = 278,
    kORI = 279,
    kSLT = 280,
    kSLTI = 281,
    kSLTIU = 282,
    kSLTU = 283,
    kSLL = 284,
    kSLLV = 285,
    kSRL = 286,
    kSRLV = 287,
    kSB = 288,
    kSH = 289,
    kSW = 290,
    kSUB = 291,
    kSUBU = 292,
    kTSL = 293,
    kLL = 294,
    kSC = 295,
    kXOR = 296,
    kXORI = 297,
    kHALT = 298,
    kNOP = 299,
    kPUSH = 300,
    kPOP = 301,
    kORG = 302,
    kCHW = 303,
    kCFW = 304,
    kBGEZAL = 305,
    kBLTZAL = 306,
    kNEWLINE = 307,
    COMMA = 308,
    LPAREN = 309,
    RPAREN = 310,
    INTEGER = 311,
    REG_NUM = 312,
    LABEL_DEC = 313,
    LABEL = 314,
    STRING = 315
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED

union YYSTYPE
{
#line 19 "asm.y" /* yacc.c:1909  */

  char  *string;
  int   number;
  int   token_val;

#line 121 "y.tab.h" /* yacc.c:1909  */
};

typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
