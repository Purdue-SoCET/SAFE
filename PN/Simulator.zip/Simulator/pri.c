
int main(){
	
	int a = 3;
	printf("%d", a);
	return 0;
}
